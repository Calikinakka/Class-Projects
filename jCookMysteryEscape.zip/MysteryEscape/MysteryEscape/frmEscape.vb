﻿'Program Name: Mystery Escape
'Justin Cook
'November 9, 2018
'The Mystery Escape Experience program allows users to find the cost and length of games in multiple cities and multiple variations of the
'mystery escape games.

Option Strict On

Public Class frmEscape
    'Variables for the frmEscape class to be used in rest of application

    Private _intOneHour As Integer = 1
    Private _intTwoHour As Integer = 2
    Private _intFourHour As Integer = 4
    Private _strGame1 As String = "Spy in the Study"
    Private _strGame2 As String = "Hidden Cellar"
    Private _strGame3 As String = "Team Building"
    Private _strGame4 As String = "The Encounter"
    Private _strGame5 As String = "Library Larceny"
    Private _strGame6 As String = "Amazing Race"


    Private Sub cboCity_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboCity.SelectedIndexChanged
        'Allows user to select the city where they'll be playing. It then calls the correct subprocedure to display available games
        Dim intCityChoice As Integer

        intCityChoice = cboCity.SelectedIndex
        lstGame.Items.Clear()
        Select Case intCityChoice
            Case 0
                DallasTeam()
            Case 1
                ParisTeam()
            Case 2
                SingaporeTeam()
        End Select

        'Makes the items shown in the window
        lblTeam.Visible = True
        txtTeam.Visible = True
        lblSelect.Visible = True
        lstGame.Visible = True
        btnFindCost.Visible = True
        btnClear.Visible = True
        lblCost.Visible = True
        lblLength.Visible = True
        lblGameType.Visible = True

        'Clears everything entered or selected
        lblGameType.Text = ""
        lblCost.Text = ""
        lblLength.Text = ""

        'Focus on the team text box
        txtTeam.Focus()

    End Sub

    Private Sub DallasTeam()
        'This procedure shows the games available in Dallas
        lstGame.Items.Add(_strGame1)
        lstGame.Items.Add(_strGame2)
        lstGame.Items.Add(_strGame3)

    End Sub
    Private Sub ParisTeam()
        'This procedure shows the games available in Paris
        lstGame.Items.Add(_strGame4)
        lstGame.Items.Add(_strGame5)

    End Sub
    Private Sub SingaporeTeam()
        'This procedure shows the games available in Singapore
        lstGame.Items.Add(_strGame2)
        lstGame.Items.Add(_strGame3)
        lstGame.Items.Add(_strGame6)

    End Sub

    Private Sub btnFindCost_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFindCost.Click
        'This button finds the cost of the game with the entered number of people, city and game selected

        Dim intTeamSize As Integer
        Dim blnNumberInTeamIsValid As Boolean = False
        Dim blnGameIsSelected As Boolean = False
        Dim intGameChoice As Integer
        Dim strSelectedTeam As String = ""
        Dim intCityChoice As Integer
        Dim intLength As Integer = 0
        Dim decTotalCost As Decimal

        'Calls the fuction to make sure the number of people entered
        'is valid and not a letter or negative number
        blnNumberInTeamIsValid = ValidateNumberInTeam()
        'Calls function to verify that the number in team is valid
        intGameChoice = ValidateGameSelection(blnGameIsSelected, strSelectedTeam)

        If (blnNumberInTeamIsValid And blnGameIsSelected) Then
            Select Case intCityChoice
                Case 0
                    decTotalCost = DallasFindCost(intGameChoice, intTeamSize, intLength)
                Case 1
                    decTotalCost = ParisFindCost(intGameChoice, intTeamSize, intLength)
                Case 2
                    decTotalCost = SingaporeFindCost(intGameChoice, intTeamSize, intLength)
            End Select
            lblGameType.Text = "Game: " & strSelectedTeam
            lblCost.Text = "Cost: " & decTotalCost.ToString("C")
            lblLength.Text = "Length: " & intLength.ToString() & " hour(s)"
        End If
    End Sub

    Private Function ValidateNumberInTeam() As Boolean
        'this function validates the entry for the number in the team.
        Dim intTeamSize As Integer
        Dim blnValidityCheck As Boolean = False
        Dim strNumberInTeamMessage As String = "Please enter the number of people in your team (2-6)"
        Dim strMessageBoxTitle As String = "Error"

        Try
            intTeamSize = Convert.ToInt32(txtTeam.Text)
            If intTeamSize >= 2 And intTeamSize <= 6 Then
                blnValidityCheck = True
            Else
                MsgBox(strNumberInTeamMessage, , strMessageBoxTitle)
                txtTeam.Focus()
                txtTeam.Clear()
            End If
        Catch Exception As FormatException
            MsgBox(strNumberInTeamMessage, , strMessageBoxTitle)
            txtTeam.Focus()
            txtTeam.Clear()
        Catch Exception As OverflowException
            MsgBox(strNumberInTeamMessage, , strMessageBoxTitle)
            txtTeam.Focus()
            txtTeam.Clear()
        Catch Exception As SystemException
            MsgBox(strNumberInTeamMessage, , strMessageBoxTitle)
            txtTeam.Focus()
            txtTeam.Clear()
        End Try
        Return blnValidityCheck

    End Function

    Private Function ValidateGameSelection(ByRef blnGame As Boolean, ByRef strGame As String) As Integer
        'Makes sure the user selected a game
        Dim intGameType As Integer
        Try
            intGameType = Convert.ToInt32(lstGame.SelectedIndex)
            strGame = lstGame.SelectedItem.ToString
            blnGame = True
        Catch Exception As SystemException
            'Detects if a game is not selected
            MsgBox("Select a game type", , "Error")
            blnGame = False
        End Try
        Return intGameType

    End Function

    Private Sub ListGame_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstGame.SelectedIndexChanged

    End Sub

    Private Function DallasFindCost(ByVal intGame As Integer, ByVal intTeam As Integer, ByRef intTime As Integer) As Decimal
        'Calculates the cost of Dallas games

        Dim decTeamCost As Decimal
        Dim decFinalCost As Decimal
        Dim decDallasGame1 As Decimal = 32D
        Dim decDallasGame2 As Decimal = 39D
        Dim decDallasGame3 As Decimal = 55D

        Select Case intGame
            Case 0
                decTeamCost = decDallasGame1
                intTime = _intOneHour
            Case 1
                decTeamCost = decDallasGame2
                intTime = _intOneHour
            Case 2
                decTeamCost = decDallasGame3
                intTime = _intTwoHour
        End Select
        decFinalCost = decTeamCost * intTime
        Return decFinalCost

    End Function
    Private Function ParisFindCost(ByVal intGame As Integer, ByVal intTeam As Integer, ByRef intTime As Integer) As Decimal
        'calculate the cost of Paris games
        Dim decTeamCost As Decimal
        Dim decFinalCost As Decimal
        Dim decParisGame4 As Decimal = 38D
        Dim decParisGame5 As Decimal = 45D

        Select Case intGame
            Case 0
                decTeamCost = decParisGame4
                intTime = _intOneHour
            Case 1
                decTeamCost = decParisGame5
                intTime = _intOneHour
        End Select
        decFinalCost = decTeamCost * intTime
        Return decFinalCost
    End Function
    Private Function SingaporeFindCost(ByVal intGame As Integer, ByVal intTeam As Integer, ByRef intTime As Integer) As Decimal
        'calculates the cost of Singapore games
        Dim decTeamCost As Decimal
        Dim decFinalCost As Decimal
        Dim decSingaporeGame2 As Decimal = 45D
        Dim decSingaporeGame3 As Decimal = 65D
        Dim decSingaporeGame6 As Decimal = 75D

        Select Case intGame
            Case 0
                decTeamCost = decSingaporeGame2
                intTime = _intOneHour
            Case 1
                decTeamCost = decSingaporeGame3
                intTime = _intTwoHour
            Case 2
                decTeamCost = decSingaporeGame6
                intTime = _intFourHour
        End Select
        decFinalCost = decTeamCost * intTime
        Return decFinalCost
    End Function

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'Resets the form, clears all entered fields and brings us back to start
        cboCity.Text = "Select City Location"
        txtTeam.Clear()
        lstGame.Items.Clear()
        lblGameType.Text = ""
        lblCost.Text = ""
        lblLength.Text = ""
        lblTeam.Visible = False
        txtTeam.Visible = False
        lblSelect.Visible = False
        lstGame.Visible = False
        btnClear.Visible = False
        btnFindCost.Visible = False
        lblGameType.Visible = False
        lblLength.Visible = False
        lblCost.Visible = False

    End Sub

    Private Sub frmEscape_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'hold the splash screen for 5 seconds
        Threading.Thread.Sleep(5000)
    End Sub
End Class
